把 PMX 放进这个文件夹。每个模型可以单独放在子文件夹里，并带上它的贴图。
动作（VMD）放进 motions 文件夹，音乐（mp3、wav、ogg）放进 music 文件夹。

Put PMX files in this folder. Each model may live in its own subfolder together with its textures.
Put VMD motions in the motions folder, and mp3, wav, or ogg audio in the music folder.
